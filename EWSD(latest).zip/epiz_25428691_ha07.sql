-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.epizy.com
-- Generation Time: Apr 02, 2020 at 09:06 AM
-- Server version: 5.6.45-86.1
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_25428691_ha07`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `mid` int(11) NOT NULL,
  `sender` varchar(20) NOT NULL,
  `reciever` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`mid`, `sender`, `reciever`, `content`, `time`) VALUES
(2, 'John', 'Jason', 'aaaa', '2020-03-25 13:12:31'),
(3, 'John', 'Jason', 'testing', '2020-03-25 13:12:31'),
(4, 'Jason', 'John', 'testing', '2020-03-25 13:12:31'),
(7, 'John', 'Korr', 'asdd', '2020-03-28 07:49:50'),
(8, 'John', 'Aron', 'aaaaaaa1234', '2020-03-28 07:53:38'),
(9, 'Jason', 'KorrT', 'ssss', '2020-03-28 08:09:33'),
(10, 'Jason', 'KorrT', '22231331313', '2020-03-28 08:10:05'),
(11, 'John', 'Aron', 'aaaaaaa', '2020-03-28 11:07:29'),
(12, 'Jason', 'KorrT', 'ok 123', '2020-03-28 11:14:15'),
(13, 'Jason', 'KorrT', 'Olla ', '2020-03-28 11:49:38'),
(14, 'KorrT', 'Jason', 'Good day', '2020-03-28 11:52:06'),
(15, 'Jason', 'KorrT', 'ssss1234', '2020-03-28 16:01:42'),
(16, 'Jason', 'KorrT', 'asssss123', '2020-03-29 06:05:25'),
(17, 'KorrT', 'Jason', 'hnkjkj', '2020-03-29 06:09:45'),
(18, 'Jason', 'KorrT', 'asdddddddddd233333', '2020-03-29 17:01:17'),
(19, 'KorrT', 'Jason', 'dddddddddddd', '2020-03-29 17:01:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`mid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
