<?php
if (!isset($_SESSION)) {
    session_start();
}

$s = "s";
$t = "t";
$a = "a";

if (isset($_SESSION['role']) &&  $_SESSION['role'] == $s) {

    header("location: S_dash.php");
    exit();
} else if (isset($_SESSION['role']) &&  $_SESSION['role'] == $t) {

    header("location: T_dash.php");
    exit();
} else if (isset($_SESSION['role']) &&  $_SESSION['role'] == $a) {

    header("location: T_assign.php");
    exit();
}

include 'dbcon.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $uname = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['psw']);
    $p_hash = password_hash($password, PASSWORD_DEFAULT);
    $sql = "SELECT * FROM user_acc WHERE Uname='$uname'";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $db_p_hash = $row['Pword'];
            $acc_status = $row['status'];
            $role = $row['role'];
        }
    } else {

        header("location: index.php");
    }

    if (!password_verify($password, $db_p_hash)) {

        echo "<script type='text/javascript'>alert('Wrong Name / Password');</script>";
    } else {

        if ($acc_status == 1) {

            echo $uname;
            setcookie("cookie_name", $uname, time() + (86400 * 30), "/");
            $_SESSION['username'] = $uname;
            $_SESSION['role'] = $role;
            $s = "s";
            $t = "t";
            $a = "a";

            if ($_SESSION['role'] == $s) {
                header("location: S_dash.php");
                exit();
            } else if ($_SESSION['role'] == $t) {
                header("location: T_dash.php");
                exit();
            } else if ($_SESSION['role'] == $a) {
                header("location: T_assign.php");
                exit();
            }
        } else {

            echo "<script type='text/javascript'>alert('Please Go Check Your Mail To Activate Account');</script>";
        }
    }

    $conn->close();
}

?>

<html>
<style>
    /* Full-width input fields */
    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        display: inline-block;
        border: 1px solid lightgray;
        background: #f1f1f1;
        border-radius: 20px;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
        background-color: #ddd;
        outline: none;
    }

    /* Set a style for all buttons */
    button {
        background-color: #4caf50;
        color: white;
        padding: 14px 20px;
        margin: 30px 0;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.8;
        margin-left: 6%;
        font-size: 20px;
    }
</style>

<head>
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="logandsign.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
</head>

<body>

    <br><br><br>
    <form class="formlg " action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
        <div class="containerlog">
            <h1>Login</h1>
            <hr>

            <br><label for="username"><b>Username</b></label>
            <br><input type="text" placeholder="Enter Username" name="username" value="<?php if (isset($_COOKIE["cookie_name"])) {
                                                                                            echo $_COOKIE["cookie_name"];
                                                                                        } ?>" required>

            <br><label for="psw"><b>Password</b></label>
            <br><input type="password" placeholder="Enter Password" name="psw" required>

            <br><br>
            <div class="button">
                <button type="submit" class="Login">Login</button>

            </div>

        </div>
    </form>

</body>

</html>