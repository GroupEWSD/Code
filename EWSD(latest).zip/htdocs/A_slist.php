<?php
ob_start();
include "dbcon.php";
include "A_nav.php";


$sql = "SELECT * FROM user_acc WHERE role = 's'";

$result = mysqli_query($conn, $sql);

?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
</head>
<style></style>
<div id="header">
    <h1 style="background-color:BLACK; ">
        <a style="height: 20%; text-align: center; color: white;"> STUDENT LIST</a></h1>
</div>
</div>
<br>
<div class="card" style="width:75%;margin:auto">
    <div class="card-body">

        <table name="dataTable" id="dataTable" class="table table-bordered" style="text-align:center">
            <thead class="thead-dark">
                <tr>
                    <th style="text-align:center;">ID</th>
                    <th style="text-align:center;width:180px">Name</th>
                    <th style="text-align:center;">gender</th>
                    <th style="text-align:center;width:200px;">Dashboard</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                ?>

                    <tr>
                        <td><?php echo $i++ ?></td>
                        <td><?php echo $row['Uname'] ?></td>
                        <td><?php echo $row['gender'] ?></td>
                        <td>
                            <?php echo "<a href=Dashboard.php?UID=" . $row['UID'] . "><button class='btn btn-primary'>VIEW</button></a>"; ?>


                    </tr>
                <?PHP
                }
                ?>
            </tbody>
        </table>
        <br>
    </div>
</div>
<br>

</html>
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            searching: false,
            "lengthMenu": [
                [-1, 3, 5, 10],
                ["All", 3, 5, 10]
            ]

        });
    });
</script>