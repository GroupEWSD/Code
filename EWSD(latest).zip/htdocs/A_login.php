<?php
if (!isset($_SESSION)) {
    session_start();
}

// if (isset($_SESSION['aname'])) { // if already login
//     header("location: A_Hlist.php"); // send to home page
//     exit();
// }

include 'dbcon.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $aname = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['psw']);
    $p_hash = password_hash($password, PASSWORD_DEFAULT);
    $sql = "SELECT * FROM a_acc WHERE Aname='$aname'";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $db_p_hash = $row['Pword'];
            $a_id = $row['am_ID'];
            $aname1 = $row['Aname'];
        }
    } else {

        header("location: A_login.php");
    }

    if (!password_verify($password, $db_p_hash)) {

        echo "<script type='text/javascript'>alert('Wrong Name / Password ');</script>";
    } else {

        if ($a_id >= 1) {

            echo $aname;
            setcookie("cookie_name", $aname, time() + (86400 * 30), "/");
            $_SESSION['aname'] = $aname;
            $_SESSION['ID'] = $a_id;
            header("location: A_Hlist.php");
            exit();
        } else {

            echo "<script type='text/javascript'>alert('Please Go Check Your Mail To Activate Account');</script>";
        }
    }
}
$conn->close();
?>


<html>

<head>
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="logandsign.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
</head>

<body>

    <br><br><br>
    <div class=".col-md-6 .offset-md-3" style="margin:auto;width:400px;padding: 15px 15px 15px;border-radius:10px">
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
            <h1>Admin Login</h1>
            <hr>

            <br><label for="username"><b>Username</b></label>
            <br><input type="text" placeholder="Enter Username" name="username" value="<?php if (isset($_COOKIE["cookie_name"])) {
                                                                                            echo $_COOKIE["cookie_name"];
                                                                                        } ?>" required>

            <br><label for="psw"><b>Password</b></label>
            <br><input type="password" placeholder="Enter Password" name="psw" required>

            <div class="button">
                <button style="color:black;" type="submit" class="Login">Login</button>

            </div>
        </form>
        <div>

            <a href="H_login.php"><button style="color:black;background-color:orange;width:auto;height:auto;font-size:12px;border-radius:20px;"><b>Hotel Login</button></a>

        </div>
    </div>


</body>

</html>