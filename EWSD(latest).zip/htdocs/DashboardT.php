<?php
include "dbcon.php";
$uid = $_GET['UID'];
$sql = "SELECT * FROM user_acc WHERE UID = '$uid'";
$result = mysqli_query($conn, $sql);
while ($rows = mysqli_fetch_array($result)) {
  $uname = $rows['Uname'];
}

$sql = "SELECT marks, count(*) as total FROM files WHERE tutor='$uname' GROUP BY marks"; // need to change t_ID
$result = mysqli_query($conn, $sql);

$sql2 = "SELECT * FROM user_acc INNER JOIN t_assign ON user_acc.Uname=t_assign.Sname WHERE t_assign.Tname='$uname'";
$result2 = mysqli_query($conn, $sql2);

if (isset($_POST["male"])) {
  $uid = $_POST['UID'];
  $sql0 = "SELECT * FROM user_acc WHERE UID = '$uid'";
  $result0 = mysqli_query($conn, $sql0);
  while ($rows = mysqli_fetch_array($result0)) {
    $uname = $rows['Uname'];
  }

  $male = "SELECT * FROM user_acc INNER JOIN t_assign ON user_acc.Uname=t_assign.Sname WHERE t_assign.Tname='$uname' AND gender='male'";
  $result2 = mysqli_query($conn, $male);
}
if (isset($_POST["female"])) {
  $uid = $_POST['UID'];
  $sql0 = "SELECT * FROM user_acc WHERE UID = '$uid'";
  $result0 = mysqli_query($conn, $sql0);
  while ($rows = mysqli_fetch_array($result0)) {
    $uname = $rows['Uname'];
  }
  $female = "SELECT * FROM user_acc INNER JOIN t_assign ON user_acc.Uname=t_assign.Sname WHERE t_assign.Tname='$uname' AND gender='female'";
  $result2 = mysqli_query($conn, $female);
}

$sql3 = "SELECT status, count(*) as total FROM files  WHERE tutor='$uname' GROUP BY status"; // need to change t_ID
$result3 = mysqli_query($conn, $sql3);

$sql4 = "SELECT status, count(*) as total FROM appointment  WHERE tutor='$uname' GROUP BY status";
$result4 = mysqli_query($conn, $sql4);
?>
<html>

<head>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

  <script type="text/javascript">
    google.charts.load("current", {
      packages: ["corechart"]
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Marks', 'total'],
        <?php

        while ($rows = mysqli_fetch_array($result)) {
          echo "['" . $rows["marks"] . "'," . $rows["total"] . "],";
        }

        ?>
      ]);

      var options = {
        title: 'Marks',
        pieHole: 0.4,
      };

      var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
      chart.draw(data, options);
    }
  </script>

  <script type="text/javascript">
    google.charts.load("current", {
      packages: ["corechart"]
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['reply', 'total'],
        <?php

        while ($rows = mysqli_fetch_array($result3)) {
          echo "['" . $rows["status"] . "'," . $rows["total"] . "],";
        }

        ?>
      ]);

      var options = {
        title: 'reply',
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));
      chart.draw(data, options);
    }
  </script>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {
      'packages': ['bar']
    });
    google.charts.setOnLoadCallback(drawStuff);

    function drawStuff() {
      var data = new google.visualization.arrayToDataTable([
        ['status', 'total'],
        <?php

        while ($rows = mysqli_fetch_array($result4)) {
          echo "['" . $rows["status"] . "'," . $rows["total"] . "],";
        }

        ?>
      ]);

      var options = {
        title: 'Chess opening moves',
        width: 900,
        legend: {
          position: 'none'
        },
        chart: {
          title: 'Appointment',
          //  subtitle: 'popularity by percentage' },
          bars: 'horizontal', // Required for Material Bar Charts.
          axes: {
            x: {
              0: {
                side: 'top',
                label: 'Percentage'
              } // Top x-axis.
            }
          },
          bar: {
            groupWidth: "90%"
          }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
  </script>

</head>

<body>
  <div id="header" style="text-align:center;">
    <h1 style="background-color:BLACK;color:white;">
      TUTOR DASHBOARD</h1>
  </div>
  <form action="DashboardT.php?UID=<?php echo $_GET['UID']; ?>" method="POST" enctype="multipart/form-data">
    <br><br>
    <div id="donutchart" style="width: 300px; height: 200px;float:left;"></div>

    <div id="piechart" style="width: 300px; height: 200px;float:left;"></div><br><br><br><br>
    <div id="top_x_div" style="width: 50px; height: 200px;"></div>
    <div style="width:80%;">
      <p class="oblique">
        <input type="hidden" name="UID" value=".<?php echo $_GET['UID']; ?>."></input>
        <font size="5">Student List</font>
      </p>
      <button type="submit" name="male">Male</button>
      <button type="submit" name="female">Female</button>
      <button onclick="location.href='T_dash.php'">All</button>
      <a href="index.php" style="color:white;padding:10px 5px;"><button style="background-color:grey;" type="button" class="btn btn-secondary">Back</button></a>

      <table name="dataTable" id="dataTable" class="table table-bordered" style="width:100%;">
        <thead>
          <tr>
            <th style="text-align:center;">Student name</th>
            <th style="text-align:center;">Gender</th>

          </tr>
        </thead>
        <tbody>
          <?php

          while ($row = mysqli_fetch_assoc($result2)) {

          ?>
            <tr>
              <td><?php echo $row['Uname'] ?></td>
              <td><?php echo $row['gender'] ?></td>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </form>

</body>

</html>
<script>
  $(document).ready(function() {
    $('#dataTable').DataTable({
      "dom": 'lrtip',
      "lengthMenu": [
        [3, 5, 10, -1],
        [3, 5, 10, "All"]
      ]

    });
  });
</script>