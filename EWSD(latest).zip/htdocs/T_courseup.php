<?php

ob_start();
include "dbcon.php";
include "T_nav.php";
$tutor = $_SESSION['username'];

$sql1 = "SELECT * FROM cwupload WHERE Tname='$tutor'";
$result1 = mysqli_query($conn, $sql1);

$files = mysqli_fetch_all($result1, MYSQLI_ASSOC);

?>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
    <link rel="stylesheet" href="dist/simplePagination.css" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="dist/jquery.simplePagination.js"></script>
    <!-- jQuery library -->
    <script src="js/jquery.min.js"></script>




</head>
<style>
    #top-nav a:hover {
        background-color: white;
        font-weight: bold;
        color: black;
    }

    #top-nav-r a:hover {
        background-color: white;
    }

    /* #container {
      border-style: solid;
      border-width: 5px;
      margin: auto;
      max-width: 50%;
      padding: 10px 10px 10px;
    } */
    #upload {
        border-style: none;
        border-width: 1px;
        margin: auto;
        padding: 10px 10px 10px;
        text-align: center;
    }

    #fileshow table {
        border-style: solid;
        border-width: 1px;
        margin: auto;
        width: auto;
    }

    #fileshow th,
    td {
        border-style: solid;
        border-width: 1px;
        margin: auto;
        width: auto;
        padding: 10px 10px 10px;
        text-align: center;
    }
</style>

<body>
    <?php
    if (isset($_POST['save'])) {

        $fname = $_POST['fname'];
        $duedate = $_POST['aDate'];
        //$tutorN = $_POST['tutor'];

        $name = $_FILES['myfile']['name'];
        $temp = $_FILES['myfile']['tmp_name'];
        $size = $_FILES['myfile']['size'];
        $target_dir = "documents/";
        $target_file = $target_dir . $name;
        //var_dump($temp);
        // Select file type
        $FileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        // Valid file extensions
        $extensions_arr = array("docx", "pdf", "zip");

        // Check extension
        if (in_array($FileType, $extensions_arr)) {
            $maxsize = 9524288000;
            // Check file size
            if (($size >= $maxsize || $size == 0)) {
                echo "<script type='text/javascript'>alert('File too large. File must be less than 5MB');</script>";
                header("refresh:0 ; url = T_courseup.php");
            } else {
                // Upload
                if (move_uploaded_file($temp, $target_file)) {
                    // Insert record
                    $sqlup = "INSERT INTO cwupload (Tname,Fname,name,size,due_date) VALUES ('$tutor','$fname','$name','$size','$duedate')";

                    mysqli_query($conn, $sqlup);
                    $INFO = "Upload Successfully";
                    echo "<script type='text/javascript'>alert('$INFO');</script>";
                    echo "<script type='text/javascript'>window.location = 'T_courseup.php';</script>";
                } else {
                    echo "<script type='text/javascript'>alert('Upload Failed.');</script>";
                }
            }
        } else {
            echo "<script type='text/javascript'>alert('Invalid file extension.');</script>";
        }
    }

    if (isset($_GET['del_id'])) {
        $delid = $_GET['del_id'];
        $sqldel = "DELETE FROM cwupload WHERE cw_ID = $delid";

        if (mysqli_query($conn, $sqldel)) {
            $INFO = "Delete SUCESSFULLY";
            echo "<script type='text/javascript'>alert('$INFO');</script>";
            header("refresh:0 ; url = T_courseup.php");
        } else {
            echo "Not Deleted";
        }
    }


    ?>
    <div id="header">
        <h1 style="background-color:BLACK;color:white ">
            COURSEWORK UPLOAD</h1>
    </div>
    <div id="container" class="container">

        <div id=" upload" class="upload form">
            <form id="upload" action="T_courseup.php" method="post" enctype="multipart/form-data">
                <table style="margin:auto;border-style:none">
                    <th style="width:150px;text-align:center;border:1px solid lightgrey;">File Name:
                    <th>
                    <td style="border:1px solid lightgrey"><input style="width:420px;" type="text" name="fname" required></td>
                    <tr>
                        <th style="width:150px;text-align:center;border:1px solid lightgrey;">Upload file:
                        <th>
                        <td style="width:auto;border:1px solid lightgrey">
                            <input style="margin-top:20px" type="file" id="myFile" name="myfile" required /><br><span>
                                *File type: "docx", "pdf", "zip"
                            </span><br>
                    </tr>
                    </td>
                    <tr>
                        <th style="width:150px;text-align:center;border:1px solid lightgrey;">Due date:
                        <th>
                        <td style="width:400px;border:1px solid lightgrey">
                            <input id="datefield" type='date' min='1899-01-01' name="aDate" max='2000-13-13' class="form-control" required></input><br><br>
                    </tr>

                </table>
                <br>
                <button style="width:auto" name="save" type="submit" class="btn btn-primary">Upload</button>

            </form>
        </div>

    </div>
    <hr>

    <div name="show" id="fileshow">
        <table>
            <thead>
                <th>No</th>
                <th>Uploaded Date & Time</th>
                <th>Due date</th>
                <th>File Name</th>
                <th>File</th>
                <th>File Size</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php
                $i = 1;
                foreach ($files as $file) : ?>

                    <tr>
                        <td style="text-align:center"><?php echo $i++ ?></td>
                        <td style="text-align:center"><?php echo $file['up_date']; ?></td>
                        <td><?php echo $file['due_date']; ?></td>
                        <td style="text-align:center"><?php echo $file['Fname']; ?></td>
                        <td><?php echo $file['name']; ?></td>

                        <td style="text-align:right"><?php echo $file['size'] / 1000 . "KB"; ?></td>
                        <td><a href="documents/<?php echo $file['name']; ?>" target="_blank" style="color:white"><button class="btn btn-primary">View / Download</button></a>
                            <br><br>
                            <a href="T_courseup.php?del_id=<?php echo $file['cw_ID'] ?>" style="color:white"><button type="button" class="btn btn-danger">Delete </button></a>
                        </td>
                    </tr>

                <?php endforeach; ?>
            </tbody>

        </table>
        <br>
    </div>

</body>

</html>
<script type="text/JavaScript">
    var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
 if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

today = yyyy+'-'+mm+'-'+dd;
document.getElementById("datefield").setAttribute("min", today);
</script>