<?php
include "dbcon.php";
$uid = $_GET['UID'];

$sql = "SELECT * FROM user_acc WHERE UID = '$uid'";
$result = mysqli_query($conn, $sql);
while ($rows = mysqli_fetch_array($result)) {
  $uname = $rows['Uname'];
}
$sql3 = "SELECT status, count(*) as total FROM files  WHERE Sname='$uname' GROUP BY status";
$result3 = mysqli_query($conn, $sql3);

$sql4 = "SELECT status, count(*) as total FROM appointment  WHERE student='$uname' GROUP BY status";
$result4 = mysqli_query($conn, $sql4);
?>
<html>

<head>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>


  <script type="text/javascript">
    google.charts.load("current", {
      packages: ["corechart"]
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['status', 'total'],
        <?php

        while ($rows = mysqli_fetch_array($result3)) {
          echo "['" . $rows["status"] . "'," . $rows["total"] . "],";
        }

        ?>
      ]);

      var options = {
        title: 'Submited Coursework with no Reply',
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));
      chart.draw(data, options);
    }
  </script>

  <script type="text/javascript">
    google.charts.load("current", {
      packages: ["corechart"]
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['status', 'total'],
        <?php

        while ($rows = mysqli_fetch_array($result4)) {
          echo "['" . $rows["status"] . "'," . $rows["total"] . "],";
        }

        ?>
      ]);

      var options = {
        title: 'Appointment',
        pieHole: 0.3,
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart1'));
      chart.draw(data, options);
    }
  </script>

</head>

<body>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
    <div id="header" style="text-align:center;">
      <h1 style="background-color:BLACK;color:white;">
        STUDENT DASHBOARD</h1>
    </div>
    <div id="piechart" style="width: 500px; height: 200px;"></div>
    <div id="piechart1" style="width: 500px; height: 200px;"></div>

    <br><br><a href="index.php" style="color:white;padding:15px 32px;"><button style=" padding:15px 32px;background-color:grey;" type="button" class="btn btn-secondary">Back</button></a>

  </form>

</body>

</html>