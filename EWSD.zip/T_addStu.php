<html style="background:white;">

<head>
  <title>Student Registration</title>
</head>
<?php
include "dbcon.php";
include 'T_nav.php';

?>
<style>
  #container {
    margin: auto;
    width: 80%;
    border: 1px solid lightgrey;
    text-align: center;
  }

  #wrapper {
    margin: auto;
    width: 70%;

    text-align: center;
  }

  #ftable td {
    padding: 2px 20px 5px;

  }

  #ftable tr,
  td {
    border: 1px solid lightgrey;
  }

  #ftable input {
    margin-top: 23px;
  }
</style>

<body>

  <div id="container">
    <div id="header">
      <h1><a>STUDENT REGISTRATION</a></h1>
    </div>
    <hr>
    <br>
    <div id="wrapper">
      <div id="content">
        <form class="form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
          <br><br><br>
          <fieldset id="fset" style="border: 0;">
            <table id="ftable">
              <tr>
                <td>Student Name</td>
                <td><input name="s_name" type="text" required></td>
              </tr>
              <tr>
                <td>Student Number</td>
                <td> <input name='s_number' type='text' required></td>
              </tr>
              <tr>
                <td>Student Contact Number</td>
                <td><input name='s_contact' type="text" required></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><input name='s_email' type="text" required></td>
              </tr>
              <tr>
                <td>Password</td>
                <td><input name='Hos_password' type="password"></td>
              </tr>
            </table>
            <br>
            <div class="form-group">
              <div class="col-md-2">
                <br>
                <button type="submit" class="btn btn-primary" style="height:5%;weight:20%;font-size:20px;">Submit</button>
              </div>
            </div>
      </div>
    </div>
  </div>
  </fieldset>
  </form>


  <div id="footer">
    <p>Footer</p>
  </div>
  </div>
</body>

</html>