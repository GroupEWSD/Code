<?php
include "dbcon.php";

$sql1 = "SELECT * FROM messages WHERE DATEDIFF(CURDATE(), time) < 7";
$result1 = mysqli_query($conn, $sql1);

$sql2 = "SELECT COUNT(mid) AS count FROM messages WHERE DATEDIFF(CURDATE(), time) < 7";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);

?>
<html>

<head>

</head>
<style>
    .show table {
        margin: auto;
    }

    .test {
        border: 1px solid black;
        border-collapse: collapse;
    }

    .test th {
        border: 1px solid black;
        padding-left: 5px;
        padding-right: 5px;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    .test td {
        border: 1px solid black;
        padding-left: 5px;
        padding-right: 5px;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    .print {
        font-size: 12px;
        border-radius: 5px;
        width: auto;
        height: auto;
        color: black;
        margin: auto;
    }
</style>

<body>
    <div class="show" name="show">
        <div style="margin:auto;text-align:center;">
            <button class="print" onclick="myFunction()"><b>Print this page</b></button>
            <button class="print" onclick="(location.href='T_assign.php')"><b>Back</b></button>


        </div>
        <br>
        <h4>Total number of messages : <?php echo $row2['count']; ?></h4>
        <hr>

        <table class="test">
            <thead>
                <th>No.</th>
                <th>Sender</th>
                <th>Reciever</th>
                <th>Content</th>

            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($result1)) {

                ?>

                    <tr>
                        <td><?php echo $i++ ?></td>
                        <td><?php echo $row['sender'] ?></td>
                        <td><?php echo $row['reciever'] ?></td>
                        <td><?php echo $row['content'] ?></td>
                    </tr>
                <?PHP
                }
                ?>
            </tbody>

        </table>
        <br>
    </div>
</body>

</html>


<script>
    function myFunction() {
        window.print();
    }
</script>