-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2020 at 10:34 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ha07`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `student` varchar(60) NOT NULL,
  `date` varchar(60) NOT NULL,
  `time` varchar(60) NOT NULL,
  `type` varchar(60) NOT NULL,
  `tutor` varchar(60) NOT NULL,
  `reason` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `student`, `date`, `time`, `type`, `tutor`, `reason`, `status`) VALUES
(1, 'John', '2020-02-04', '2', 'virtual', 'tutorA', '', 'Pending'),
(2, 'John', '2020-02-04', '2', 'virtual', 'tutorA', '', 'Pending'),
(3, 'John', '2020-02-06', '4.00pm-5.00pm', 'realtime', 'Ryan', '', 'Accept'),
(4, 'John', '2020-02-04', '4.00pm-5.00pm', 'realtime', 'Ryan', 'Consultation on project', 'Accept'),
(5, 'John', '', '2:00pm-3.00pm', 'virtual', 'Annida', '', 'Pending'),
(6, 'John', '2020-02-04', '4.00pm-5.00pm', 'realtime', 'Annida', '131231', 'Pending'),
(7, 'John', '2020-02-04', '2:00pm-3.00pm', 'realtime', 'Ryan', '13131', 'Decline'),
(8, 'John', '2020-02-04', '4.00pm-5.00pm', 'realtime', 'Ryan', '123123', 'Pending'),
(9, 'John', '2020-02-04', '2:00pm-3.00pm', 'virtual', 'Annida', '123123', 'Pending'),
(10, 'Ryan', '2020-03-12', '2:00pm-3.00pm', 'virtual', 'Ryan', '12313', 'Accept'),
(11, 'Ryan', '2020-03-04', '2:00pm-3.00pm', 'virtual', 'Ryan', '12331', 'Accept'),
(12, 'Ryan', '2020-03-03', '2:00pm-3.00pm', 'virtual', 'Ryan', 'sdsf', 'Accept'),
(13, 'Ryan', '2020-03-03', '2:00pm-3.00pm', 'virtual', 'Ryan', 'sdsf', 'Accept'),
(14, 'Ryan', '2020-03-05', '2:00pm-3.00pm', 'realtime', 'Ryan', '1231', 'Accept'),
(15, 'Mack', '2020-03-02', '2:00pm-3.00pm', 'virtual', 'Ryan', '123', 'Accept'),
(16, 'Mack', '2020-03-11', '2:00pm-3.00pm', 'virtual', 'Ryan', '12', 'Accept'),
(17, 'Mack', '2020-03-10', '4.00pm-5.00pm', 'virtual', 'Ryan', '12312', 'Accept'),
(18, 'Ryan', '2020-03-05', '2:00pm-3.00pm', 'virtual', 'Ryan', '', 'Accept'),
(19, 'Ryan', '2020-03-04', '2:00pm-3.00pm', 'virtual', 'Ryan', '31', 'Accept'),
(20, 'Ryan', '2020-03-02', '2:00pm-3.00pm', 'virtual', 'Ryan', 'wqe', 'Accept'),
(21, 'Ryan', '2020-03-18', '2:00pm-3.00pm', 'virtual', 'Ryan', 'wwww', 'Accept'),
(22, 'Ryan', '2020-03-04', '2:00pm-3.00pm', 'virtual', 'Ryan', '2131', 'Decline'),
(23, 'Ryan', '', '2:00pm-3.00pm', 'virtual', 'Ryan', '12312', 'Pending'),
(24, 'Ryan', '2020-03-17', '2:00pm-3.00pm', 'virtual', 'Ryan', '1231', 'Pending'),
(25, 'Aron', '2020-03-19', '2:00pm-3.00pm', 'virtual', 'John', 'as', 'Pending'),
(26, 'Jason', '2020-03-27', '2:00pm-3.00pm', 'virtual', 'Tutor', '', 'Pending'),
(27, 'Jason', '2020-03-19', '2:00pm-3.00pm', 'virtual', '', '', 'Pending'),
(28, 'Jason', '2020-03-19', '2:00pm-3.00pm', 'virtual', '', 'gfll', 'Pending'),
(29, 'Jason', '2020-03-11', '2:00pm-3.00pm', 'realtime', 'KorrT', 'xvzxvz', 'Pending'),
(30, 'Jason', '2020-03-25', '2:00pm-3.00pm', 'virtual', 'John', 'adsadsd', 'Accept'),
(31, 'Jason', '2020-03-27', '2:00pm-3.00pm', 'virtual', 'AronT', 'asdads', 'Pending'),
(32, 'Jason', '2020-04-04', '2:00pm-3.00pm', 'virtual', 'KorrT', '15244477962', 'Pending'),
(33, 'Jason', '2020-04-05', '4.00pm-5.00pm', 'realtime', 'KorrT', 'testing 123', 'Accept'),
(34, 'Jason', '2020-03-31', '4.00pm-5.00pm', 'virtual', 'KorrT', 'wwwwwxa', 'Pending'),
(35, 'Jason', '2020-04-02', '2:00pm-3.00pm', 'virtual', 'Tutor Name', 'dfccaad', 'Pending'),
(36, 'Jason', '2020-04-03', '2:00pm-3.00pm', 'virtual', 'KorrT', 'aaaaaa', 'Accept');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `bid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `content` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`bid`, `name`, `content`, `time`) VALUES
(1, 'Jason', 'adfefkjrhkrjgkhrdgjrhkgdkhrhd', '2020-03-03 10:50:03'),
(2, 'admin', 'ghfjfjtfhtf', '2020-03-03 10:50:03'),
(3, 'Jason', '<p>sdgfsdgsg</p>', '2020-03-03 10:50:03'),
(4, 'Jason', '<p>111111111111</p>', '2020-03-03 10:50:03'),
(5, 'Jason', '<table style=\"height: 95px;\" width=\"176\">\r\n<tbody>\r\n<tr>\r\n<td>afa</td>\r\n<td>fasasfa</td>\r\n<td>&nbsp;</td>\r\n</tr>\r\n<tr>\r\n<td>faf</td>\r\n<td>fwf</td>\r\n<td>&nbsp;</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2020-03-03 10:57:56'),
(6, 'Jason', '<p>post blog</p>', '2020-03-03 11:05:04'),
(7, 'Jason', '<p>post blog</p>', '2020-03-03 11:06:59'),
(8, 'Jason', '<p>post blog</p>', '2020-03-03 11:08:17'),
(9, 'Jason', '<p>post blog</p>', '2020-03-03 11:08:36'),
(10, 'Jason', '<p>post blog</p>', '2020-03-03 11:08:58'),
(11, 'Jason', '<p>xaxx</p>', '2020-03-25 09:49:59'),
(12, 'Jason', '<p>ssssssssssssss</p>', '2020-03-28 07:48:07'),
(13, 'Jason', '<p>asdddd</p>', '2020-03-28 11:14:07'),
(14, 'Jason', '<p>Hello World</p>', '2020-03-28 11:49:23'),
(15, 'Jason', '<p>ccccc</p>', '2020-03-29 06:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `cwupload`
--

CREATE TABLE `cwupload` (
  `cw_ID` int(11) NOT NULL,
  `Tname` varchar(255) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `due_date` datetime NOT NULL,
  `Fname` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cwupload`
--

INSERT INTO `cwupload` (`cw_ID`, `Tname`, `up_date`, `due_date`, `Fname`, `name`, `size`) VALUES
(6, 'KorrT', '2020-03-26 15:31:26', '2021-02-03 13:00:00', 'asd3', 'CW_COMP1649_51_ver1_1920(1).docx', 22466),
(7, 'John', '2020-03-26 15:00:46', '2020-03-27 00:00:00', 'aaaaa', 'CW_COMP1649_51_ver1_1920(1).docx', 22466),
(9, 'John', '2020-03-28 07:39:23', '2020-03-31 00:00:00', 'aaaa', 'Discussion Writing Techniques.docx', 18608),
(10, 'John', '2020-03-28 11:04:31', '2020-04-02 00:00:00', 'Test1', 'Mobile User Experience VS webGUI_Week2(1).docx', 16514),
(11, 'KorrT', '2020-03-28 16:06:39', '2020-04-03 00:00:00', 'vvvvvvvv', 'Discussion Writing Techniques.docx', 18608),
(12, 'KorrT', '2020-03-29 06:07:38', '2020-04-05 00:00:00', 'saddd', 'CW_COMP1649_51_ver1_1920(1).docx', 22466);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `ID` int(11) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Fname` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `comment` text NOT NULL,
  `reply` text NOT NULL,
  `tutor` varchar(60) NOT NULL,
  `marks` int(11) NOT NULL,
  `Sname` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`ID`, `up_date`, `Fname`, `name`, `size`, `comment`, `reply`, `tutor`, `marks`, `Sname`, `status`) VALUES
(1, '2020-03-04 12:23:58', 'dwadwdawd', 'Mobile User Experience VS webGUI_Week2.docx', 16514, 'sfsefesfesfiuiouiouo', 'sssss', 'KorrT', 50, 'Jason', 'replied'),
(15, '2020-03-26 09:12:47', 'asd', 'EWSD.zip', 13463, 'aaaaaaaaaaaaa', '', 'KorrT', 0, 'Jason', 'unreplied'),
(17, '2020-03-26 09:15:36', 'asdads', 'Exercise.zip', 2534, 'aaaaaaaaaaaaa', 'gg wp 000001111', 'John', 60, 'Aron', 'replied'),
(18, '2020-03-26 13:53:54', 'Test12', 'Mobile User Experience VS webGUI_Week2.docx', 16514, 'aaaaaaaaaaa', 'lorem ipsum ...', 'John', 20, 'Jason', 'replied'),
(19, '2020-03-28 11:13:24', 'Test12', 'CW_COMP1649_51_ver1_1920(1).docx', 22466, 'aaaaa', '', 'KorrT', 0, 'Jason', 'unreplied'),
(20, '2020-03-28 11:48:39', 'Test12345', 'Mobile User Experience VS webGUI_Week2(1).docx', 16514, '123456', 'ssss124gg', 'KorrT', 70, 'Jason', 'replied'),
(21, '2020-03-29 06:04:34', 'Test12', 'CW_COMP1649_51_ver1_1920(1).docx', 22466, 'cccc', '', 'KorrT', 0, 'Jason', 'unreplied');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `mid` int(11) NOT NULL,
  `sender` varchar(20) NOT NULL,
  `reciever` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`mid`, `sender`, `reciever`, `content`, `time`) VALUES
(1, 'John', '', 'aaaaa', '2020-03-01 13:12:31'),
(2, 'John', 'Jason', 'aaaa', '2020-03-25 13:12:31'),
(3, 'John', 'Jason', 'testing', '2020-03-25 13:12:31'),
(4, 'Jason', 'John', 'testing', '2020-03-25 13:12:31'),
(5, 'John', '', 'asddd', '2020-03-28 07:48:24'),
(6, 'John', 'Aron', '', '2020-03-28 07:49:45'),
(7, 'John', 'Korr', 'asdd', '2020-03-28 07:49:50'),
(8, 'John', 'Aron', 'aaaaaaa1234', '2020-03-28 07:53:38'),
(9, 'Jason', 'KorrT', 'ssss', '2020-03-28 08:09:33'),
(10, 'Jason', 'KorrT', '22231331313', '2020-03-28 08:10:05'),
(11, 'John', 'Aron', 'aaaaaaa', '2020-03-28 11:07:29'),
(12, 'Jason', 'KorrT', 'ok 123', '2020-03-28 11:14:15'),
(13, 'Jason', 'KorrT', 'Olla ', '2020-03-28 11:49:38'),
(14, 'KorrT', 'Jason', 'Good day', '2020-03-28 11:52:06'),
(15, 'Jason', 'KorrT', 'ssss1234', '2020-03-28 16:01:42'),
(16, 'Jason', 'KorrT', 'asssss123', '2020-03-29 06:05:25'),
(17, 'KorrT', 'Jason', 'hnkjkj', '2020-03-29 06:09:45'),
(18, 'Jason', 'KorrT', 'asdddddddddd233333', '2020-03-29 17:01:17'),
(19, 'KorrT', 'Jason', 'dddddddddddd', '2020-03-29 17:01:39');

-- --------------------------------------------------------

--
-- Table structure for table `t_assign`
--

CREATE TABLE `t_assign` (
  `AID` int(10) NOT NULL,
  `Tname` varchar(60) NOT NULL,
  `Sname` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_assign`
--

INSERT INTO `t_assign` (`AID`, `Tname`, `Sname`) VALUES
(13, 'KorrT', 'Jason'),
(14, 'John', 'Aron'),
(16, 'KorrT', 'Alex'),
(17, 'John', 'Korr');

-- --------------------------------------------------------

--
-- Table structure for table `user_acc`
--

CREATE TABLE `user_acc` (
  `UID` int(10) NOT NULL,
  `Uname` varchar(255) NOT NULL,
  `Pword` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `status` int(10) NOT NULL,
  `Uemail` varchar(60) NOT NULL,
  `Unum` varchar(60) NOT NULL,
  `Ucontact` varchar(60) NOT NULL,
  `Activation` varchar(255) NOT NULL,
  `role` varchar(60) NOT NULL,
  `Assign` varchar(20) NOT NULL DEFAULT 'Unassign'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_acc`
--

INSERT INTO `user_acc` (`UID`, `Uname`, `Pword`, `gender`, `status`, `Uemail`, `Unum`, `Ucontact`, `Activation`, `role`, `Assign`) VALUES
(1, 'Aron', '$2y$10$m.UU42SUsbfy6Eps8WuINeeyKK6JhW6WSEcx.pXavWMZXDNzvtd7W', 'male', 0, 'johnleekk@hotmail.com', 'stu123', '0192222353', '34a1e6ca04e4e8da4cbb575069d61f1d', 's', 'Assigned'),
(2, 'Alex', '$2y$10$HIHERIwCznWr9Uf.lkDG7OcPwc1aDcatStJg18RUN67SExqITWO5S', 'male', 0, 'johnleekk@hotmail.com', 'stu543', '0192222353', '8282ae4d318aece5903acd68ffbb8b68', 's', 'Assigned'),
(3, 'Korr', '$2y$10$lo5kcfOHDew00yG7XgJwF.Ht7zElJ505SAbGiNiFPI3NAvfc1n136', 'female', 1, 'johnleekk@hotmail.com', 'stu556', '0192222353', '365fec25a8d672f9e386d35adcc4507d', 's', 'Assigned'),
(4, 'KorrT', '$2y$10$lo5kcfOHDew00yG7XgJwF.Ht7zElJ505SAbGiNiFPI3NAvfc1n136', 'female', 1, 'johnleekk@hotmail.com', 'stu556', '0192222353', '365fec25a8d672f9e386d35adcc4507d', 't', 'Unassign'),
(5, 'AronT', '$2y$10$m.UU42SUsbfy6Eps8WuINeeyKK6JhW6WSEcx.pXavWMZXDNzvtd7W', 'male', 1, 'johnleekk@hotmail.com', 'stu123', '0192222353', '34a1e6ca04e4e8da4cbb575069d61f1d', 't', 'Unassign'),
(6, 'Jason', '$2y$10$9fL7CxWqBOMAusec5E1t2upo0khEOFSuxYRSDHbqXVP5fXIWXTfPi', 'male', 1, 'johnleekk@hotmail.com', 'stu556', '0192222353', '365fec25a8d672f9e386d35adcc4507d', 's', 'Assigned'),
(7, 'John', '$2y$10$9JkLljRq8OeWNRial83TtuLDoYAhBf7a3UUhWOzOcKxBG7NFoY0mS', 'male', 1, 'johnleekk@hotmail.com', 'stu556', '0192222353', '365fec25a8d672f9e386d35adcc4507d', 't', 'Unassign'),
(8, 'Admin', '$2y$10$wWpVCnrULrF/JD2MLov6F.Rm3235AtmNcQpjBeJjHnw.5EOr6PaVS', 'male', 1, 'johnleekk@hotmail.com', 'stu556', '0192222353', '365fec25a8d672f9e386d35adcc4507d', 'a', 'Unassign');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `cwupload`
--
ALTER TABLE `cwupload`
  ADD PRIMARY KEY (`cw_ID`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `t_assign`
--
ALTER TABLE `t_assign`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `user_acc`
--
ALTER TABLE `user_acc`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cwupload`
--
ALTER TABLE `cwupload`
  MODIFY `cw_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `t_assign`
--
ALTER TABLE `t_assign`
  MODIFY `AID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_acc`
--
ALTER TABLE `user_acc`
  MODIFY `UID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
