<?php
include "S_nav.php";
include 'dbcon.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require 'vendor\autoload.php';


if (!isset($_SESSION)) {
	session_start();
}

if (!isset($_SESSION['username'])) {
	header("Location: index.php");
	exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


	$sName = mysqli_real_escape_string($conn, $_SESSION['username']);
	$aDate = mysqli_real_escape_string($conn, $_POST['aDate']);
	$aTime = mysqli_real_escape_string($conn, $_POST['aTime']);
	$aType = mysqli_real_escape_string($conn, $_POST['aType']);
	$aTutor = mysqli_real_escape_string($conn, $_POST['aTutor']);
	$aReason = mysqli_real_escape_string($conn, $_POST['aReason']);

	$sql = "SELECT * FROM user_acc WHERE Uname ='$aTutor' AND role ='t'";
	$result = mysqli_query($conn, $sql);

	if ($result->num_rows > 0) {

		while ($row = $result->fetch_assoc()) {


			$tMail = $row['Uemail'];
		}
	}

	if (!empty($sName) && !empty($aDate) && !empty($aTime) && !empty($aType) && !empty($aTutor) && !empty($aReason)) {

		$get_user = "SELECT * FROM appointment WHERE student ='$sName' AND date ='$aDate' AND time = '$aTime' AND status ='Accept'";
		$rowresult = mysqli_query($conn, $get_user);


		if ($rowresult->num_rows > 0) {

			$message = "Appointment already make.";
			echo "<script type='text/javascript'>alert('$message');</script>";
		} else {

			$sql = "INSERT INTO appointment(student,date, time, type, tutor,reason)
						VALUES ('$sName', '$aDate', '$aTime', '$aType', '$aTutor', '$aReason')";

			if ($result = mysqli_query($conn, $sql)) {

				$msg = "Task Uploaded Successfully";
				echo "<script type='text/javascript'>alert('$msg');</script>";






				$mail = new PHPMailer(TRUE);
				$mail->isSMTP();
				$mail->SMTPDebug = SMTP::DEBUG_SERVER;
				$mail->Host = 'smtp.gmail.com';
				$mail->Port = 587;
				$mail->SMTPSecure = "tls";
				$mail->SMTPAuth = true;
				$mail->Username = 'bryanteo98@gmail.com';
				$mail->Password = 'vgbbsgckqegqwdia';


				$mail->setFrom('jojo@jotaro.com', 'DIO');

				$mail->addAddress($tMail, $aTutor);

				$mail->Subject = 'Email Verification';

				$mail->Body = "<html></body><div style='padding-top:8px;'>Your have a appointment awaiting for confirmation</div>
					</body></html>";

				$mail->isHTML(true);

				if ($mail->send()) {

					$message = "Email Sent";
					echo "<script type='text/javascript'>alert('$message');</script>";
					echo "<script type='text/javascript'>window.location.href='S_appoint.php';</script>";
				} else {

					echo "Error, Email not sent.";
				}
			}
		}
	} else {

		$msg = "Task Failed to Upload";
		echo "<script type='text/javascript'>alert('$msg');</script>";

		echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
?>
<html>
<title> Appointment </title>

<head>
	<style>
		p {
			font-family: Arial;
			font-size: 18px;
			color: black;
		}

		button {
			background-color: #215ECF;
			border: none;
			color: white;
			padding: 10px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
		}

		.div1 {
			border-radius: 12px;
		}

		.div2 {
			border-radius: 12px;
		}

		table,
		th,
		td {
			border: 1px solid black;
			border-collapse: collapse;
		}

		th,
		td {
			padding: 15px;
		}

		a {
			color: blue;
		}
	</style>
</head>

<body>
	<div id="header" style="text-align:center;">
		<h1 style="background-color:BLACK;color:white;">
			APPOINTMENT</h1>
	</div>
	<div class="div div1" align="center" style="width:auto;height:auto;margin-top:0px">
		<br>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
			<div>
				<table style="border:1px solid black;">
					<tr>
						<td>Date :</td>
						<td><input style="border-radius:20px;height:40px" id="datefield" type='date' min='1899-01-01' name="aDate" max='2000-13-13' required></input></td>

					</tr>
					<tr>
						<td>Time :</td>
						<td><select style="width:auto;" id="aTime" name="aTime" required>
								<option value="2:00pm-3.00pm">2:00pm - 3.00pm</option>
								<option value="4.00pm-5.00pm">4.00pm - 5.00pm</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>Appointment Type :</td>
						<td><select style="width:auto;" id="aType" name="aType" required>
								<option value="virtual">Virtual</option>
								<option value="realtime">Real-Time</option>
							</select></td>
					</tr>
					<tr>
						<td>Tutor :</td>
						<td> <select style="width:auto;" id="aTutor" name="aTutor" required>

								<?php

								$u = $_SESSION['username'];
								echo "<option value=''>Tutor Name</option>";
								$sql = "SELECT * FROM t_assign WHERE Sname ='$u'";
								$resultx = mysqli_query($conn, $sql);

								if (mysqli_num_rows($resultx) > 0) {


									while ($row = mysqli_fetch_array($resultx)) {

										$tutor = $row['Tname'];
										echo "<option value=$tutor>$tutor</option>";
									}
								}
								?>
							</select></td>
					</tr>
					<tr>
						<td>Reason : </td>
						<td><textarea name="aReason" placeholder="Reason..." cols="37" rows="5" Style="font-size:14px;" required></textarea></td>
					<tr>
						<!-- <td>
						<td><button type="submit" name="appointment" class="button">Make Appointment</button>
						<td></td> -->
					</tr>
					</tr>
				</table>
				<button type="submit" name="appointment" class="button">Make Appointment</button>
			</div><br>
		</form>
		<div>
</body>
<script>
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1; //January is 0!
	var yyyy = today.getFullYear();
	if (dd < 10) {
		dd = '0' + dd
	}
	if (mm < 10) {
		mm = '0' + mm
	}

	today = yyyy + '-' + mm + '-' + dd;
	document.getElementById("datefield").setAttribute("min", today);
</script>

</html>