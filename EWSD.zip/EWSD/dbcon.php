<?php
define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DATABASE", "ha07");

//establish database connection
$conn = mysqli_connect(HOST, USER, PASSWORD, DATABASE);
if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
} else {
    // echo " Connect Successfully";
}
?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="box.css">
    <link rel="stylesheet" type="text/css" href="logandsign.css">
</head>

</html>

<?php
// define("HOST", "sql107.epizy.com");
// define("USER", "epiz_25428691");
// define("PASSWORD", "57gcaavr6hC");
// define("DATABASE", "epiz_25428691_ha07");

// //establish database connection
// $conn = mysqli_connect(HOST, USER, PASSWORD, DATABASE);
// if (!$conn) {
//     die("Connection Failed: " . mysqli_connect_error());
// } else {
//     // echo " Connect Successfully";
// }
?>
<!-- 
<html>

<head>
    <link rel="stylesheet" type="text/css" href="box.css">
    <link rel="stylesheet" type="text/css" href="logandsign.css">
</head>

</html> -->