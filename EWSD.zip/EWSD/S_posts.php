<?php
include "S_nav.php";
include "dbcon.php";

if (!isset($_SESSION)) {
  session_start();
}
if (!isset($_SESSION['username'])) {
  header("location:index.php");
  exit();
}
if (isset($_POST['save'])) {
  //$n=$_SESSION['User'];
  $t = $_POST['text'];
  $uname = $_SESSION['username'];
  if (!empty($t)) {
    $sql1 = "INSERT INTO blog(name,content) VALUES('$uname','$t')";
    $result1 = mysqli_query($conn, $sql1);
  } else {
    $m = "Cannot upload empty blog.";
    echo "<script type='text/javascript'>alert('$m');</script>";
  }
}
?>
<html>

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!------ Include the above in your HEAD tag ---------->

  <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

</head>
<style>
  #top-nav a:hover {
    background-color: white;
    font-weight: bold;
    color: black;
  }

  #top-nav-r a:hover {
    background-color: white;
  }

  .container {
    border-style: solid;
    border-width: 1px;
    margin: auto;
    width: 70%;
    padding: 10;

  }

  #savebtn {
    float: left;
    color: black;
    width: auto;
  }

  td {
    border: 1px solid black;
  }
</style>

<body>

  <div id="header" style="text-align:center;">
    <h1 style="background-color:BLACK;color:white;">
      POST BLOG</h1>
  </div>
  <div class="container">
    <div id="row-LAC" class="row-LAC">
      <script src="//tinymce.cachefly.net/4.0/tinymce.min.js"></script>
      <script>
        tinymce.init({
          selector: "textarea",
          menu: {
            table: {
              title: 'Table',
              items: 'inserttable tableprops deletetable | cell row column'
            }
          },
          plugins: [
            "advlist autolink lists link image charmap preview anchor",
            "searchreplace visualblocks code fullscreen",
            "insertdatetime media table contextmenu paste"
          ],
          toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        });
      </script>


      </script>
      <?php
      $sql = "SELECT * FROM blog ORDER BY time DESC";
      $result = mysqli_query($conn, $sql);



      if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          $name = $row['name'];
          $content = $row['content'];
          $time = $row['time'];

          echo "<h3> $name <small>	&nbsp; $time</small></h3>
                   <div style='color:black;border:1px solid black;padding-top:5px;
				   padding-bottom:10px;padding-left:10px;padding-right:10px;border-radius:10px;'>
				   <p color:black;>$content</p></div>
				<hr>
				</h3>
				<hr>
                
				";
        }
      }
      ?>
      <!-- the comments -->

    </div>

    <div class="well">
      <h4><i class="fa fa-paper-plane-o"></i> POST A BLOG:</h4>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <textarea name="text" class="form-control" rows="5"></textarea>
        </div>
        <button id="savebtn" style="float:left;" type="submit" name="save" value="" class="btn btn-primary"><i class="fa fa-reply"></i> Submit</button>
      </form>
    </div>

  </div>

</body>

</html>