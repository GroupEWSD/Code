<?php
include "S_nav.php";
include 'dbcon.php';


if (!isset($_SESSION)) {
	session_start();
}

if (!isset($_SESSION['username'])) {
	header("Location: index.php");
	exit();
}

  $sName =$_SESSION['username'];
  $sql = "SELECT * FROM appointment WHERE student ='$sName' ";
  $result1 = mysqli_query($conn, $sql);
  
	

?>
<html>
<title> Appointment </title>

<head>
	<style>
		p {
			font-family: Arial;
			font-size: 18px;
			color: black;
		}

		button {
			background-color: #215ECF;
			border: none;
			color: white;
			padding: 10px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
		}

		.div1 {
			border-radius: 12px;
		}

		.div2 {
			border-radius: 12px;
		}

		table,
		th,
		td {
			border: 1px solid black;
			border-collapse: collapse;
		}

		th,
		td {
			padding: 15px;
		}

		a {
			color: blue;
		}
		.content{
		  height:230px;
		  width:90%;
	  }
	</style>
</head>

<body>
	<div id="header" style="text-align:center;">
		<h1 style="background-color:BLACK;color:white;">
			APPOINTMENT LIST</h1>
	</div>
	<div class="div div1" align="center" style="width:auto;height:auto;margin-top:0px">
		<br>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
				<table name="dataTable" id="dataTable" class="table table-bordered" style="width:90%; margin-left:100px">
                <thead>
                    <tr>
						<th style="text-align:center;">Student</th>
						<th style="text-align:center;">Date</th>
						<th style="text-align:center;">Time</th>
						<th style="text-align:center;">Type</th>
						<th style="text-align:center;">Reason</th>
						<th style="text-align:center;">Status</th>
						<th style="text-align:center;">Video</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                   while ($row = mysqli_fetch_assoc($result1)) { 
						$vlocation=$row['v_location'];
                    ?>

                        <tr>
							 <td><?php echo $row['student'] ?></td>
							   <td><?php echo $row['date'] ?></td>
							    <td><?php echo $row['time'] ?></td>
								<td><?php echo $row['type'] ?></td>
								 <td><?php echo $row['reason'] ?></td>
								  <td><?php echo $row['status'] ?></td>
                            <td style="width:100px;"><?php echo "<video src='".$vlocation."' controls width='320px' height='200px'></video>" ?></td>
							
                        </tr>
                    <?php
                   }
                    ?>
                </tbody>
            </table>	
				
		</form>
		</div>
</body>


</html>
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
           "dom": 'lrtip', "lengthMenu": [
                [3, 5, 10, -1],
                [3, 5, 10, "All"]
            ]

        });
    });
</script>