<?php
include "dbcon.php";

$sql1 = "SELECT * FROM user_acc WHERE role = 's' AND Assign = 'Unassign'";
$result1 = mysqli_query($conn, $sql1);

?>
<html>

<head>

</head>
<style>
    .show table {
        margin: auto;
    }

    .test {
        border: 1px solid black;
        border-collapse: collapse;
    }

    .test th {
        border: 1px solid black;
        padding-left: 5px;
        padding-right: 5px;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    .test td {
        border: 1px solid black;
        padding-left: 5px;
        padding-right: 5px;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    .print {
        font-size: 12px;
        border-radius: 5px;
        width: auto;
        height: auto;
        color: black;
        margin: auto;
    }
</style>

<body>
    <div class="show" name="show">
        <div style="margin:auto;text-align:center;">
            <button class="print" onclick="myFunction()"><b>Print this page</b></button>
            <button class="print" onclick="(location.href='T_assign.php')"><b>Back</b></button>

        </div>
        <hr>

        <table class="test">
            <thead>
                <th>No.</th>
                <th>Student Name</th>
                <th>Gender</th>
                <th>Student Number</th>
                <th>Assign Status</th>

            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($result1)) {

                ?>

                    <tr>
                        <td><?php echo $i++ ?></td>
                        <td><?php echo $row['Uname'] ?></td>
                        <td><?php echo $row['gender'] ?></td>
                        <td><?php echo $row['Unum'] ?></td>
                        <td><?php echo $row['Assign'] ?></td>
                    </tr>
                <?PHP
                }
                ?>
            </tbody>

        </table>
        <br>
    </div>
</body>

</html>


<script>
    function myFunction() {
        window.print();
    }
</script>