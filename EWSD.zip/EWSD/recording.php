<?php
include "T_nav.php";
include 'dbcon.php';


if (!isset($_SESSION)) {
	session_start();
}

if (!isset($_SESSION['username'])) {
	header("Location: index.php");
	exit();
}
$id=$_GET['id'];
  
	 if(isset($_POST['upload'])){

     $maxsize = 524288000; // 500MB

	  
	  // $aTutor =$_POST['aTutor'];
       $name = $_FILES['file']['name'];
	   $temp=$_FILES['file']['tmp_name'];
	   $size=$_FILES['file']['size'];
       $target_dir = "videos/";
       $target_file = 'videos/' . $name;
		//var_dump($temp);
       // Select file type
       $videoFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

       // Valid file extensions
       $extensions_arr = array("mp4");
	   
	   if(!file_exists('videos/')){
			
		  mkdir("videos");
	   }
       // Check extension
       if( in_array($videoFileType,$extensions_arr) ){
 
          // Check file size
		$query = "UPDATE appointment SET v_name='".$temp."', v_location='".$target_file."' WHERE id=$id";
		if (mysqli_query($conn,$query)){
            // Upload
            if(move_uploaded_file($temp, $target_file)){
              // Insert record
              
 //$query = "INSERT INTO appointment(v_name,v_location) VALUES('".$temp."','".$target_file."')"; 
			  $INFO="Upload Successfully";
              echo "<script type='text/javascript'>alert('$INFO');</script>";
			  header("refresh:0;url=appoint_list.php");
            }
			else{
				  echo "<script type='text/javascript'>alert('Upload Failed.');</script>";
				  echo "Error: " . $query . "<br>" . $conn->error;
			}
		}
          

       }else{
          echo "<script type='text/javascript'>alert('Invalid file extension.');</script>";
       }
	 }

?>
<html>
<title> Appointment </title>

<head>
	<style>
		p {
			font-family: Arial;
			font-size: 18px;
			color: black;
		}

		button {
			background-color: #215ECF;
			border: none;
			color: white;
			padding: 10px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
		}

		.div1 {
			border-radius: 12px;
		}

		.div2 {
			border-radius: 12px;
		}

		table,
		th,
		td {
			border: 1px solid black;
			border-collapse: collapse;
		}

		th,
		td {
			padding: 15px;
		}

		a {
			color: blue;
		}
	</style>
</head>

<body>
	<div id="header" style="text-align:center;">
		<h1 style="background-color:BLACK;color:white;">
			UPLOAD VIDEO</h1>
	</div>
	<div class="div div1" align="center" style="width:auto;height:auto;margin-top:0px">
		<br>
		<form action="recording.php?id=<?php echo $_GET['id'];?>" method="POST" enctype="multipart/form-data">
				<div>

				 <h2>Upload recording video (mp4)</h2>	
				 <input type='file' name='file' required/>
				 <input type='submit' value='Upload' name='upload'><br><br>
				<input type="hidden" value="<?php echo $_GET['id'];?>" name="id"/>
				 
				</div>
				
		</form>
		</div>
</body>


</html>