<?php

include "dbcon.php";
include "S_nav.php";


if (empty($_SESSION)) {

	session_start();
}

if (isset($_POST['save'])) {
	$n = $_SESSION['username'];
	$t = $_POST["tutor"];
	$stu = $n;
	$content = $_POST["message"];
	//$tutor=$row['tutor_name'];
	$sql1 = "INSERT INTO messages(reciever,sender,content) VALUES('$t','$stu','$content')";
	if ($result1 = mysqli_query($conn, $sql1)) {
		echo "<script type='text/javascript'>alert('$INFO');</script>";
		echo "<script type='text/javascript'>window.location = 'S_message.php';</script>";
	}
}
$n = $_SESSION['username'];
$sql2 = "SELECT * FROM messages WHERE sender='$n' OR reciever='$n' ORDER BY time DESC";
$result2 = mysqli_query($conn, $sql2);



//$sql="SELECT * FROM tutor WHERE tutor_name=$tutor AND student='$n'";
?>

<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

<body>
	<div id="header" style="text-align:center;">
		<h1 style="background-color:BLACK;color:white;">
			MESSAGE</h1>
	</div>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
		<div style="width:500px; height:200px; border:1px solid; margin-top:50px;margin:auto;background:lightgray;border-radius:20px" align='center'>

			<?php
			$n = $_SESSION['username'];
			$sql = "SELECT * FROM t_assign WHERE Sname='$n'";
			$result = mysqli_query($conn, $sql);

			echo "<select name='tutor' style='margin-top:50px;'required>";
			echo "<option value='' selected disabled>Tutor Name</option>";

			if (mysqli_num_rows($result) > 0) {
				echo "<label for='text'>tutor:</label>";

				while ($row = mysqli_fetch_array($result)) {

					$tutor = $row['Tname'];
					echo "<option value=$tutor>$tutor</option>";
				}
			} else {
				echo "No User !";
			}
			echo "</select>";

			?>
			<br><br><textarea class="message-input" name="message" placeholder="write your message" required></textarea><br>
			<br><button type="submit" name="save">Save</button>
		</div>

		<hr>
		<div style="width:600px; height:230px;margin-top:50px; margin:auto;" align="center">
			<table name="dataTable" id="dataTable" class="table table-bordered" style="width:100%;">
				<thead>
					<tr>
						<th style="text-align:center;">Sender</th>
						<th style="text-align:center;">Reciever</th>
						<th style="text-align:center;">Content</th>
						<th style="text-align:center;">Time</th>
					</tr>
				</thead>
				<tbody>
					<?php
					while ($row = mysqli_fetch_assoc($result2)) {

					?>

						<tr>
							<td><?php echo $row['sender'] ?></td>
							<td><?php echo $row['reciever'] ?></td>
							<td><?php echo $row['content'] ?></td>
							<td><?php echo $row['time'] ?></td>
						</tr>
					<?php
					}
					?>
				</tbody>
			</table>
			<br>
		</div>
	</form>

</body>

</html>
<script>
	$(document).ready(function() {
		$('#dataTable').DataTable({
			"lengthMenu": [
				[3, 5, 10, -1],
				[3, 5, 10, "All"]
			]

		});
	});
</script>